
import { GoogleGenAI, Chat, GenerateContentResponse, HarmCategory, HarmBlockThreshold, GenerateContentParameters } from "@google/genai";
import { ImagePayload } from "../types"; // Assuming types.ts is in the parent directory

let chat: Chat | null = null;

const API_KEY = process.env.API_KEY;

const SYSTEM_INSTRUCTION = `You are 'Weather Whiz', a friendly and highly knowledgeable meteorologist. 
Your primary goal is to explain weather phenomena to curious learners in an engaging, clear, and easy-to-understand manner.
When an image is provided, analyze it carefully and explain any visible weather phenomena. If the user provides text along with the image, address their specific query in relation to the image.
Key characteristics of your responses:
- Clarity and Simplicity: Use simple language and relatable analogies. Avoid overly technical jargon unless specifically requested, and if so, explain it clearly.
- Engaging Tone: Be enthusiastic and conversational. Make learning about weather fun!
- Accuracy: Ensure all information provided is accurate and up-to-date.
- Structure: For complex topics, break them down into smaller, digestible parts. Use markdown for formatting like **bold text** for emphasis, bullet points for lists, or simple headings (e.g., ### Heading).
- Encouraging: Be patient and supportive of learners.
- Examples: Use examples to illustrate concepts whenever possible (e.g., "Cumulus clouds look like fluffy cotton balls...").
- Focus: Stick to weather-related topics. If asked about something unrelated, politely steer the conversation back to weather.
- Safety: Do not provide any harmful, unethical, or inappropriate content. If a query touches on dangerous weather, include safety advice if relevant.
`;

export const initChatService = async (): Promise<string | null> => {
  if (!API_KEY) {
    console.error("Gemini API Key is not configured in process.env.API_KEY");
    return "API_KEY_MISSING";
  }
  try {
    const ai = new GoogleGenAI({ apiKey: API_KEY });
    chat = ai.chats.create({
      model: 'gemini-2.5-flash-preview-04-17',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });
    return null; // Success
  } catch (error) {
    console.error("Error initializing Gemini chat:", error);
    return "INIT_FAILED";
  }
};

export const sendMessageToAI = async (message: string, image?: ImagePayload): Promise<string> => {
  if (!chat) {
    throw new Error("Chat service not initialized. Call initChatService first or wait for initialization.");
  }

  try {
    let response: GenerateContentResponse;
    if (image) {
      const imagePart = {
        inlineData: {
          mimeType: image.mimeType,
          data: image.data,
        },
      };
      
      const userText = message.trim();
      const promptText = userText 
        ? `User's question about the image: "${userText}". Please explain the weather phenomena in the image, addressing this question.`
        : "Explain the weather phenomena visible in this image in detail. What can we learn from it?";

      const textPart = { text: promptText };
      
      // For multimodal, we don't use chat.sendMessage, we use ai.models.generateContent directly
      // Re-initialize ai for this specific call structure if needed or ensure chat can handle parts.
      // For simplicity and directness with multimodal, let's use the direct model call:
      const ai = new GoogleGenAI({ apiKey: API_KEY }); // Assuming API_KEY is accessible
      response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17', // Ensure this model supports image input
        contents: {
          parts: [textPart, imagePart],
          // System instruction is often part of the model config in chat, 
          // for direct generateContent, it might be passed differently or implied by chat setup.
          // If SYSTEM_INSTRUCTION is critical here, it should be passed if the API supports it for this call type.
          // The `chat` object already has the system instruction configured.
          // However, the prompt for `generateContent` might need it explicitly if not using `chat.sendMessage`.
          // The provided snippet for `generateContent` with multiple parts does not show systemInstruction in `contents`.
          // It is part of `config` when calling `generateContent`
        },
         config: { // Add config here for system instruction if making a direct model call
          systemInstruction: SYSTEM_INSTRUCTION 
        }
      });

    } else {
      response = await chat.sendMessage({ message });
    }
    
    const responseText = response.text;
    if (responseText === undefined || responseText === null) {
      console.warn("Gemini API returned an empty or undefined text response.", response);
      return "I'm sorry, I couldn't generate a response for that. Could you try rephrasing your question or providing a different image?";
    }
    return responseText;
  } catch (error: any) {
    console.error("Error sending message to Gemini:", error);
    if (error.message && error.message.includes("API key not valid")) {
      throw new Error("The API key is not valid. Please check your configuration.");
    }
    if (error.message && error.message.toLowerCase().includes("quota")) {
      throw new Error("You may have exceeded your API quota. Please check your Gemini API dashboard.");
    }
    // Check for specific content blocking errors
    if (error.response && error.response.promptFeedback && error.response.promptFeedback.blockReason) {
      return `I'm sorry, I can't respond to that. Reason: ${error.response.promptFeedback.blockReason}`;
    }
    // Check if the error is due to the model not supporting image input (though gemini-2.5-flash should)
    if (error.message && error.message.includes("does not support image input")) {
         throw new Error("The current AI model does not support image input. Please contact support.");
    }

    throw new Error("Failed to get a response from Weather Whiz. The weather patterns might be too complex right now, or there was an issue with the image!");
  }
};
