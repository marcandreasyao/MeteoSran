
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Header } from './components/Header';
import { ChatInterface } from './components/ChatInterface';
import { Message, MessageRole, ImagePayload } from './types';
import { initChatService, sendMessageToAI } from './services/geminiService';
import { ErrorMessage } from './components/ErrorMessage';
import { Footer } from './components/Footer';

export type Theme = 'light' | 'dark';

export interface CurrentInputState {
  text: string;
  imageFile: File | null;
}

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [chatInitialized, setChatInitialized] = useState<boolean>(false);
  const [currentInput, setCurrentInput] = useState<CurrentInputState>({ text: '', imageFile: null });
  const [theme, setTheme] = useState<Theme>('light');

  useEffect(() => {
    const storedTheme = localStorage.getItem('theme') as Theme | null;
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    const initialTheme = storedTheme || (prefersDark ? 'dark' : 'light');
    setTheme(initialTheme);
  }, []);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };
  
  const initialWelcomeMessage: Message = useMemo(() => ({
    id: crypto.randomUUID(),
    role: MessageRole.MODEL,
    text: "Hello! I'm Weather Whiz. Ask me anything about clouds, storms, hurricanes, or other weather wonders! You can also upload an image of a weather phenomenon for me to explain.",
    timestamp: new Date(),
  }),[]);

  const chatServiceInitialization = useCallback(async () => {
    try {
      const initError = await initChatService();
      if (initError) {
        if (initError === "API_KEY_MISSING") {
          setError("Configuration error: The API_KEY is missing. Please ensure it's set up correctly.");
        } else {
          setError("Failed to initialize the chat service. Please try refreshing the page.");
        }
        setChatInitialized(false);
      } else {
        setMessages([initialWelcomeMessage]);
        setChatInitialized(true);
        setError(null);
      }
    } catch (e) {
      setError("An unexpected error occurred during chat initialization.");
      setChatInitialized(false);
    }
  }, [initialWelcomeMessage]);

  useEffect(() => {
    chatServiceInitialization();
  }, [chatServiceInitialization]);

  const handleSendMessage = async (inputText: string, imageFile?: File | null) => {
    if ((!inputText.trim() && !imageFile) || isLoading || !chatInitialized) return;

    setIsLoading(true);
    setError(null);
    
    let imagePayload: ImagePayload | undefined = undefined;
    if (imageFile) {
      try {
        const base64Data = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve((reader.result as string).split(',')[1]);
          reader.onerror = error => reject(error);
          reader.readAsDataURL(imageFile);
        });
        imagePayload = {
          data: base64Data,
          mimeType: imageFile.type,
          name: imageFile.name,
        };
      } catch (e) {
        console.error("Error processing image:", e);
        setError("Could not process the image. Please try a different one.");
        setIsLoading(false);
        return;
      }
    }

    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: MessageRole.USER,
      text: inputText,
      timestamp: new Date(),
      ...(imagePayload && { image: imagePayload }),
    };
    setMessages(prevMessages => [...prevMessages, userMessage]);
    setCurrentInput({ text: '', imageFile: null }); // Clear input and image

    try {
      const aiResponseText = await sendMessageToAI(inputText, imagePayload);
      const aiMessage: Message = {
        id: crypto.randomUUID(),
        role: MessageRole.MODEL,
        text: aiResponseText,
        timestamp: new Date(),
      };
      setMessages(prevMessages => [...prevMessages, aiMessage]);
    } catch (e: any) {
      const errorMessageText = e.message || "Sorry, I couldn't fetch a response. Please try again.";
      setError(errorMessageText);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSampleQuestion = (question: string) => {
    setCurrentInput({ text: question, imageFile: null }); // Clear any selected image
    // Small delay to allow state to update before sending, ensuring textarea shows question
    setTimeout(() => handleSendMessage(question), 0);
  };

  return (
    <div className="flex flex-col h-screen">
      <Header theme={theme} toggleTheme={toggleTheme} />
      <main className="flex-grow flex flex-col overflow-hidden p-2 md:p-4">
        {error && !chatInitialized && (
          <div className="flex-grow flex items-center justify-center p-4">
            <ErrorMessage message={error} isCritical={true} />
          </div>
        )}
        {chatInitialized && (
            <ChatInterface
              messages={messages}
              isLoading={isLoading}
              error={error && chatInitialized ? error : null}
              onSendMessage={handleSendMessage}
              onSampleQuestion={handleSampleQuestion}
              currentInputState={currentInput}
              setCurrentInputState={setCurrentInput}
            />
        )}
         {!chatInitialized && !error && (
          <div className="flex-grow flex items-center justify-center">
            <p className="text-slate-700 dark:text-slate-300 text-lg">Initializing Weather Whiz...</p>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default App;
