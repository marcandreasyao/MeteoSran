
import React from 'react';
import { Theme } from '../App'; // Assuming Theme type is exported from App.tsx

interface HeaderProps {
  theme: Theme;
  toggleTheme: () => void;
}

export const Header: React.FC<HeaderProps> = ({ theme, toggleTheme }) => {
  return (
    <header 
      className="p-4 w-full z-20
                 bg-white/30 dark:bg-slate-800/30 backdrop-blur-lg 
                 shadow-lg border-b border-white/20 dark:border-slate-700/30"
      role="banner"
    >
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center">
          <span className="material-symbols-outlined text-3xl mr-2 text-sky-600 dark:text-sky-400">
            filter_drama
          </span>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-800 dark:text-slate-100">
            Weather Whiz
          </h1>
        </div>
        <button
          onClick={toggleTheme}
          className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400 transition-colors"
          aria-label={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
        >
          <span className="material-symbols-outlined text-slate-700 dark:text-slate-200">
            {theme === 'light' ? 'dark_mode' : 'light_mode'}
          </span>
        </button>
      </div>
    </header>
  );
};
